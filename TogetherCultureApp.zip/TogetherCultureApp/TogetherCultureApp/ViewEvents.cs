﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace TogetherCultureApp
{
    public partial class ViewEvents : UserControl
    {
        EventData sampleData;
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public ViewEvents()
        {
            InitializeComponent();
            displayEvents();

        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            displayEvents();
        }

        private String imagePath;

        public void clearFields()
        {
            nameField.Text = "";
            descriptionField.Text = "";
            eventDateField.Text = "";
        }

        public void displayEvents()
        {
            EventData dab = new EventData();
            List<EventData> listData = dab.getAllEventsData();
            dataGridView1.DataSource = listData;
        }

        private int eventID = 0;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                eventID = (int)row.Cells[0].Value;
                nameField.Text = row.Cells[1].Value.ToString();
                descriptionField.Text = row.Cells[2].Value.ToString();
                eventDateField.Text = row.Cells[3].Value.ToString();
            }
        }

        private void _clearBtn_Click(object sender, EventArgs e)
        {
            if (
                 nameField.Text == ""
                || descriptionField.Text == ""
                || eventDateField.Value == null
                )
            {
                MessageBox.Show("Please select any event", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure you want to cancel booking:"
                        + eventID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();
                            string updateData = "DELETE FROM  bookings where event_id = @event_id and member_id = @member_id";
                            using (SqlCommand cmd = new SqlCommand(updateData, connect))
                            {
                                cmd.Parameters.AddWithValue("@event_id", eventID);
                                cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);
                                cmd.ExecuteNonQuery();
                                displayEvents();
                                MessageBox.Show("Cancelled successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                clearFields();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
            }
            clearFields();
        }

        private void book_now_btn_Click(object sender, EventArgs e)
        {
            if (
                 nameField.Text == ""
                || descriptionField.Text == ""
                || eventDateField.Value == null
                )
            {
                MessageBox.Show("Please select event", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure to book this event:"
                        + eventID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();
                            DateTime today = DateTime.Today;
                        
                            string insertData = "INSERT INTO bookings " +
                            "(member_id,event_id, booking_date) " +
                            "VALUES(@member_id, @event_id, @booking_date)";
                            using (SqlCommand cmd = new SqlCommand(insertData, connect))
                            {
                                cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);
                                cmd.Parameters.AddWithValue("@event_id", eventID);
                                cmd.Parameters.AddWithValue("@booking_date", today.ToString());
                                cmd.ExecuteNonQuery();
                                displayEvents();
                                MessageBox.Show("Booked event successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                clearFields();
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
            }
        }

        private void _cancel_Btn_Click(object sender, EventArgs e)
        {
            if (
                 nameField.Text == ""
                || descriptionField.Text == ""
                || eventDateField.Value == null
                )
            {
                MessageBox.Show("Please select any event", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure you want to cancel booking:"
                        + eventID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();
                            string updateData = "DELETE FROM  bookings where event_id = @event_id and member_id = @member_id";
                            using (SqlCommand cmd = new SqlCommand(updateData, connect))
                            {
                                cmd.Parameters.AddWithValue("@event_id", eventID);
                                cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);
                                cmd.ExecuteNonQuery();
                                displayEvents();
                                MessageBox.Show("Cancelled successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                clearFields();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

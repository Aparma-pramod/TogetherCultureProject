﻿
namespace TogetherCultureApp
{
    partial class ManageUsers
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.statusField = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ClearMemberButton = new System.Windows.Forms.Button();
            this.DeleteMemberButton = new System.Windows.Forms.Button();
            this.UpdateMemberButton = new System.Windows.Forms.Button();
            this.AddMemberButton = new System.Windows.Forms.Button();
            this.registeredDateField = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.interestField = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.memberTypeField = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.emailIdField = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.passwordField = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.userNameField = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.show_all_button = new System.Windows.Forms.Button();
            this.filterButton = new System.Windows.Forms.Button();
            this.searchType = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.allMemberDataGrid = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.check_events_button = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.allMemberDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.check_events_button);
            this.panel1.Controls.Add(this.statusField);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.ClearMemberButton);
            this.panel1.Controls.Add(this.DeleteMemberButton);
            this.panel1.Controls.Add(this.UpdateMemberButton);
            this.panel1.Controls.Add(this.AddMemberButton);
            this.panel1.Controls.Add(this.registeredDateField);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.interestField);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.memberTypeField);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.emailIdField);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.passwordField);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.userNameField);
            this.panel1.Controls.Add(this.label2);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(18, 342);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(845, 209);
            this.panel1.TabIndex = 0;
            // 
            // statusField
            // 
            this.statusField.AutoCompleteCustomSource.AddRange(new string[] {
            "Approved",
            "Unapproved",
            "Rejected"});
            this.statusField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusField.FormattingEnabled = true;
            this.statusField.Items.AddRange(new object[] {
            "Not approved",
            "Approved",
            "Rejected"});
            this.statusField.Location = new System.Drawing.Point(530, 89);
            this.statusField.Name = "statusField";
            this.statusField.Size = new System.Drawing.Size(137, 24);
            this.statusField.TabIndex = 22;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(481, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(48, 16);
            this.label8.TabIndex = 21;
            this.label8.Text = "Status:";
            // 
            // ClearMemberButton
            // 
            this.ClearMemberButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.ClearMemberButton.FlatAppearance.BorderSize = 0;
            this.ClearMemberButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClearMemberButton.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearMemberButton.ForeColor = System.Drawing.Color.White;
            this.ClearMemberButton.Location = new System.Drawing.Point(491, 158);
            this.ClearMemberButton.Name = "ClearMemberButton";
            this.ClearMemberButton.Size = new System.Drawing.Size(100, 33);
            this.ClearMemberButton.TabIndex = 20;
            this.ClearMemberButton.Text = "CLEAR";
            this.ClearMemberButton.UseVisualStyleBackColor = false;
            this.ClearMemberButton.Click += new System.EventHandler(this.user_clearBbtn_Click);
            // 
            // DeleteMemberButton
            // 
            this.DeleteMemberButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.DeleteMemberButton.FlatAppearance.BorderSize = 0;
            this.DeleteMemberButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteMemberButton.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteMemberButton.ForeColor = System.Drawing.Color.White;
            this.DeleteMemberButton.Location = new System.Drawing.Point(373, 158);
            this.DeleteMemberButton.Name = "DeleteMemberButton";
            this.DeleteMemberButton.Size = new System.Drawing.Size(100, 33);
            this.DeleteMemberButton.TabIndex = 19;
            this.DeleteMemberButton.Text = "DELETE";
            this.DeleteMemberButton.UseVisualStyleBackColor = false;
            this.DeleteMemberButton.Click += new System.EventHandler(this.member_deleteBtn_Click);
            // 
            // UpdateMemberButton
            // 
            this.UpdateMemberButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.UpdateMemberButton.FlatAppearance.BorderSize = 0;
            this.UpdateMemberButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateMemberButton.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateMemberButton.ForeColor = System.Drawing.Color.White;
            this.UpdateMemberButton.Location = new System.Drawing.Point(243, 158);
            this.UpdateMemberButton.Name = "UpdateMemberButton";
            this.UpdateMemberButton.Size = new System.Drawing.Size(100, 33);
            this.UpdateMemberButton.TabIndex = 18;
            this.UpdateMemberButton.Text = "UPDATE";
            this.UpdateMemberButton.UseVisualStyleBackColor = false;
            this.UpdateMemberButton.Click += new System.EventHandler(this.member_updateBtn_Click);
            // 
            // AddMemberButton
            // 
            this.AddMemberButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.AddMemberButton.FlatAppearance.BorderSize = 0;
            this.AddMemberButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddMemberButton.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddMemberButton.ForeColor = System.Drawing.Color.White;
            this.AddMemberButton.Location = new System.Drawing.Point(125, 158);
            this.AddMemberButton.Name = "AddMemberButton";
            this.AddMemberButton.Size = new System.Drawing.Size(100, 33);
            this.AddMemberButton.TabIndex = 17;
            this.AddMemberButton.Text = "ADD";
            this.AddMemberButton.UseVisualStyleBackColor = false;
            this.AddMemberButton.Click += new System.EventHandler(this.view_member_addBtn_Click);
            // 
            // registeredDateField
            // 
            this.registeredDateField.Location = new System.Drawing.Point(530, 57);
            this.registeredDateField.Name = "registeredDateField";
            this.registeredDateField.Size = new System.Drawing.Size(194, 20);
            this.registeredDateField.TabIndex = 16;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(421, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 16);
            this.label9.TabIndex = 15;
            this.label9.Text = "Registered Date:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // interestField
            // 
            this.interestField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.interestField.FormattingEnabled = true;
            this.interestField.Items.AddRange(new object[] {
            "caring",
            "sharing",
            "creating",
            "experiencing",
            "working"});
            this.interestField.Location = new System.Drawing.Point(530, 19);
            this.interestField.Name = "interestField";
            this.interestField.Size = new System.Drawing.Size(137, 24);
            this.interestField.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(468, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Interest:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // memberTypeField
            // 
            this.memberTypeField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.memberTypeField.FormattingEnabled = true;
            this.memberTypeField.Items.AddRange(new object[] {
            "Community Member",
            "Key Access Member",
            "Creative Workspace Member"});
            this.memberTypeField.Location = new System.Drawing.Point(251, 121);
            this.memberTypeField.Name = "memberTypeField";
            this.memberTypeField.Size = new System.Drawing.Size(144, 24);
            this.memberTypeField.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(153, 124);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Member Type:";
            // 
            // emailIdField
            // 
            this.emailIdField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailIdField.Location = new System.Drawing.Point(250, 88);
            this.emailIdField.Name = "emailIdField";
            this.emailIdField.Size = new System.Drawing.Size(145, 23);
            this.emailIdField.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(209, 91);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Email:";
            // 
            // passwordField
            // 
            this.passwordField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordField.Location = new System.Drawing.Point(251, 54);
            this.passwordField.Name = "passwordField";
            this.passwordField.Size = new System.Drawing.Size(145, 23);
            this.passwordField.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(180, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password :";
            // 
            // userNameField
            // 
            this.userNameField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameField.Location = new System.Drawing.Point(250, 19);
            this.userNameField.Name = "userNameField";
            this.userNameField.Size = new System.Drawing.Size(145, 23);
            this.userNameField.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(176, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "User Name:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.show_all_button);
            this.panel2.Controls.Add(this.filterButton);
            this.panel2.Controls.Add(this.searchType);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.allMemberDataGrid);
            this.panel2.Controls.Add(this.label1);
            this.panel2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel2.Location = new System.Drawing.Point(18, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(845, 314);
            this.panel2.TabIndex = 1;
            // 
            // show_all_button
            // 
            this.show_all_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.show_all_button.FlatAppearance.BorderSize = 0;
            this.show_all_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.show_all_button.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_all_button.ForeColor = System.Drawing.Color.White;
            this.show_all_button.Location = new System.Drawing.Point(612, 16);
            this.show_all_button.Name = "show_all_button";
            this.show_all_button.Size = new System.Drawing.Size(100, 26);
            this.show_all_button.TabIndex = 24;
            this.show_all_button.Text = "SHOW ALL";
            this.show_all_button.UseVisualStyleBackColor = false;
            this.show_all_button.Click += new System.EventHandler(this.show_all_button_click);
            // 
            // filterButton
            // 
            this.filterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.filterButton.FlatAppearance.BorderSize = 0;
            this.filterButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.filterButton.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filterButton.ForeColor = System.Drawing.Color.White;
            this.filterButton.Location = new System.Drawing.Point(496, 16);
            this.filterButton.Name = "filterButton";
            this.filterButton.Size = new System.Drawing.Size(100, 26);
            this.filterButton.TabIndex = 23;
            this.filterButton.Text = "FILTER";
            this.filterButton.UseVisualStyleBackColor = false;
            this.filterButton.Click += new System.EventHandler(this.user_filter_button_click);
            // 
            // searchType
            // 
            this.searchType.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchType.FormattingEnabled = true;
            this.searchType.Items.AddRange(new object[] {
            "Individual Members",
            "Non Members"});
            this.searchType.Location = new System.Drawing.Point(317, 18);
            this.searchType.Name = "searchType";
            this.searchType.Size = new System.Drawing.Size(159, 24);
            this.searchType.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(240, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 14);
            this.label5.TabIndex = 23;
            this.label5.Text = "Search By:";
            // 
            // allMemberDataGrid
            // 
            this.allMemberDataGrid.AllowUserToAddRows = false;
            this.allMemberDataGrid.AllowUserToDeleteRows = false;
            this.allMemberDataGrid.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.allMemberDataGrid.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.allMemberDataGrid.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.allMemberDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.allMemberDataGrid.EnableHeadersVisualStyles = false;
            this.allMemberDataGrid.Location = new System.Drawing.Point(21, 55);
            this.allMemberDataGrid.Name = "allMemberDataGrid";
            this.allMemberDataGrid.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.allMemberDataGrid.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.allMemberDataGrid.RowHeadersVisible = false;
            this.allMemberDataGrid.Size = new System.Drawing.Size(803, 237);
            this.allMemberDataGrid.TabIndex = 2;
            this.allMemberDataGrid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "All Members";
            // 
            // check_events_button
            // 
            this.check_events_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.check_events_button.FlatAppearance.BorderSize = 0;
            this.check_events_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.check_events_button.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.check_events_button.ForeColor = System.Drawing.Color.White;
            this.check_events_button.Location = new System.Drawing.Point(612, 158);
            this.check_events_button.Name = "check_events_button";
            this.check_events_button.Size = new System.Drawing.Size(100, 33);
            this.check_events_button.TabIndex = 23;
            this.check_events_button.Text = "VIEW EVENTS";
            this.check_events_button.UseVisualStyleBackColor = false;
            this.check_events_button.Click += new System.EventHandler(this.view_events_button_click);
            
            // 
            // ManageUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "ManageUsers";
            this.Size = new System.Drawing.Size(880, 565);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.allMemberDataGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox passwordField;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox userNameField;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox emailIdField;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox interestField;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox memberTypeField;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DateTimePicker registeredDateField;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button ClearMemberButton;
        private System.Windows.Forms.Button DeleteMemberButton;
        private System.Windows.Forms.Button UpdateMemberButton;
        private System.Windows.Forms.Button AddMemberButton;
        private System.Windows.Forms.DataGridView allMemberDataGrid;
        private System.Windows.Forms.ComboBox statusField;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox searchType;
        private System.Windows.Forms.Button filterButton;
        private System.Windows.Forms.Button show_all_button;
        private System.Windows.Forms.Button check_events_button;
    }
}

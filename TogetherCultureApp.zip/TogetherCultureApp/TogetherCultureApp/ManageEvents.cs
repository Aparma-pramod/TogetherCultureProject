﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using TogetherCommunitySystem;

namespace TogetherCultureApp
{
    public partial class ManageEvents : UserControl
    {
        EventData sampleData;
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public ManageEvents()
        {
            InitializeComponent();
            displayEvents();

        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            displayEvents();
        }

        private String imagePath;


        private void event_filter_button_click(object sender, EventArgs e)
        {
            if (searchText.Text == "")
            {
                MessageBox.Show("Please enter event name", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                EventData dib = new EventData();
                string type = searchText.Text;
                List<EventData> listData = dib.getEventsByName(type);
                dataGridView1.DataSource = listData;
            }
        }

        private void event_show_all_button_click(object sender, EventArgs e)
        {
           displayEvents();
        }

        private void addEvents_addBtn_Click(object sender, EventArgs e)
        {
            if (
                nameField.Text == ""
                || descriptionField.Text == ""
                || eventDateField.Value == null
                || orgField.Text == ""
                || attendanceField.Text == "")
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State == ConnectionState.Closed)
                {
                    try
                    {
                        connect.Open();
                        string insertData = "INSERT INTO events " +
                            "(event_name,event_description, event_date, attendance, organiser_name) " +
                            "VALUES(@name, @description, @event_date, @attendance, @org_name)";
                        using (SqlCommand cmd = new SqlCommand(insertData, connect))
                        {
                            cmd.Parameters.AddWithValue("@name", nameField.Text.Trim());
                            cmd.Parameters.AddWithValue("@description", descriptionField.Text.Trim());
                            cmd.Parameters.AddWithValue("@event_date", eventDateField.Value);
                            cmd.Parameters.AddWithValue("@attendance", attendanceField.Text.Trim());
                            cmd.Parameters.AddWithValue("@org_name", orgField.Text.Trim());
                            cmd.ExecuteNonQuery();
                            displayEvents();
                            MessageBox.Show("Added event successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            clearFields();
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
        }

        public void clearFields()
        {
            nameField.Text = "";
            descriptionField.Text = "";
            eventDateField.Text = "";
            orgField.Text = "";
            attendanceField.Text = "";
        }

        public void displayEvents()
        {
            EventData dab = new EventData();
            List<EventData> listData = dab.getAllEventsData();
            dataGridView1.DataSource = listData;
        }

        private int eventID = 0;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                eventID = (int)row.Cells[0].Value;
                nameField.Text = row.Cells[1].Value.ToString();
                descriptionField.Text = row.Cells[2].Value.ToString();
                eventDateField.Text = row.Cells[3].Value.ToString();
                attendanceField.Text = row.Cells[4].Value.ToString();
                orgField.Text = row.Cells[5].Value.ToString();
            }
        }

        private void addBooks_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void addEvents_updateBtn_Click(object sender, EventArgs e)
        {
            if (
                 nameField.Text == ""
                || descriptionField.Text == ""
                || eventDateField.Value == null
                || attendanceField.Text == ""
                || orgField.Text == "")
            {
                MessageBox.Show("Please select item first", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure you want to update event:"
                        + eventID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();

                            string updateData = "UPDATE events SET event_name = @event_name" +
                                ", event_description = @event_description, event_date = @event_date" +
                                ", attendance = @attendance, organiser_name = @organiser_name WHERE event_id = @event_id";

                            using (SqlCommand cmd = new SqlCommand(updateData, connect))
                            {
                                cmd.Parameters.AddWithValue("@event_name", nameField.Text.Trim());
                                cmd.Parameters.AddWithValue("@event_description", descriptionField.Text.Trim());
                                cmd.Parameters.AddWithValue("@event_date", eventDateField.Value);
                                cmd.Parameters.AddWithValue("@attendance", attendanceField.Text.Trim());
                                cmd.Parameters.AddWithValue("@organiser_name", orgField.Text.Trim());
                                cmd.Parameters.AddWithValue("@event_id", eventID);

                                cmd.ExecuteNonQuery();

                                displayEvents();

                                MessageBox.Show("Updated event successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                clearFields();
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
            }
        }

        private void addEvents_deleteBtn_Click(object sender, EventArgs e)
        {
            if (
                 nameField.Text == ""
                || descriptionField.Text == ""
                || eventDateField.Value == null
                || attendanceField.Text == ""
                || orgField.Text == "")
            {
                MessageBox.Show("Please select any event first", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure you want to delete event ID:"
                        + eventID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();
                            string updateData = "DELETE FROM  events where event_id = @event_id";
                            using (SqlCommand cmd = new SqlCommand(updateData, connect))
                            {
                                cmd.Parameters.AddWithValue("@event_id", eventID);
                                cmd.ExecuteNonQuery();
                                displayEvents();
                                MessageBox.Show("Deleted successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                clearFields();
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}

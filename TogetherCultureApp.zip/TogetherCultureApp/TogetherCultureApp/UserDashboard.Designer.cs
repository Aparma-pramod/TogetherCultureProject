﻿
namespace TogetherCultureApp
{
    partial class UserDashboard
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.totalUnbookedEventsLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.totalEventsBookedLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.totalModulesBookedLabel = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.totalModulesUnbookedLabel = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.totalEventsLabel = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.totalModulesLabel = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(13, 18);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(855, 528);
            this.panel1.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Salmon;
            this.panel3.Controls.Add(this.totalUnbookedEventsLabel);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(574, 27);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(230, 150);
            this.panel3.TabIndex = 3;
            // 
            // totalUnbookedEventsLabel
            // 
            this.totalUnbookedEventsLabel.AutoSize = true;
            this.totalUnbookedEventsLabel.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalUnbookedEventsLabel.ForeColor = System.Drawing.Color.White;
            this.totalUnbookedEventsLabel.Location = new System.Drawing.Point(189, 106);
            this.totalUnbookedEventsLabel.Name = "totalUnbookedEventsLabel";
            this.totalUnbookedEventsLabel.Size = new System.Drawing.Size(30, 33);
            this.totalUnbookedEventsLabel.TabIndex = 2;
            this.totalUnbookedEventsLabel.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(89, 37);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 19);
            this.label4.TabIndex = 0;
            this.label4.Text = "Events UnBooked";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkGray;
            this.panel2.Controls.Add(this.totalEventsBookedLabel);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(294, 27);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(230, 150);
            this.panel2.TabIndex = 0;
            // 
            // totalEventsBookedLabel
            // 
            this.totalEventsBookedLabel.AutoSize = true;
            this.totalEventsBookedLabel.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalEventsBookedLabel.ForeColor = System.Drawing.Color.White;
            this.totalEventsBookedLabel.Location = new System.Drawing.Point(189, 106);
            this.totalEventsBookedLabel.Name = "totalEventsBookedLabel";
            this.totalEventsBookedLabel.Size = new System.Drawing.Size(30, 33);
            this.totalEventsBookedLabel.TabIndex = 2;
            this.totalEventsBookedLabel.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(91, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 19);
            this.label1.TabIndex = 0;
            this.label1.Text = "Events Booked";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkGray;
            this.panel4.Controls.Add(this.totalModulesBookedLabel);
            this.panel4.Controls.Add(this.pictureBox3);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Location = new System.Drawing.Point(294, 250);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(230, 150);
            this.panel4.TabIndex = 4;
            // 
            // totalModulesBookedLabel
            // 
            this.totalModulesBookedLabel.AutoSize = true;
            this.totalModulesBookedLabel.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalModulesBookedLabel.ForeColor = System.Drawing.Color.White;
            this.totalModulesBookedLabel.Location = new System.Drawing.Point(189, 106);
            this.totalModulesBookedLabel.Name = "totalModulesBookedLabel";
            this.totalModulesBookedLabel.Size = new System.Drawing.Size(30, 33);
            this.totalModulesBookedLabel.TabIndex = 2;
            this.totalModulesBookedLabel.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(91, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "Modules Booked";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Salmon;
            this.panel5.Controls.Add(this.totalModulesUnbookedLabel);
            this.panel5.Controls.Add(this.pictureBox4);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Location = new System.Drawing.Point(574, 250);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(230, 150);
            this.panel5.TabIndex = 5;
            // 
            // totalModulesUnbookedLabel
            // 
            this.totalModulesUnbookedLabel.AutoSize = true;
            this.totalModulesUnbookedLabel.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalModulesUnbookedLabel.ForeColor = System.Drawing.Color.White;
            this.totalModulesUnbookedLabel.Location = new System.Drawing.Point(189, 106);
            this.totalModulesUnbookedLabel.Name = "totalModulesUnbookedLabel";
            this.totalModulesUnbookedLabel.Size = new System.Drawing.Size(30, 33);
            this.totalModulesUnbookedLabel.TabIndex = 2;
            this.totalModulesUnbookedLabel.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(80, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(144, 19);
            this.label6.TabIndex = 0;
            this.label6.Text = "Modules Unbooked";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.IndianRed;
            this.panel6.Controls.Add(this.totalEventsLabel);
            this.panel6.Controls.Add(this.pictureBox5);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Location = new System.Drawing.Point(21, 27);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(230, 150);
            this.panel6.TabIndex = 6;
            // 
            // totalEventsLabel
            // 
            this.totalEventsLabel.AutoSize = true;
            this.totalEventsLabel.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalEventsLabel.ForeColor = System.Drawing.Color.White;
            this.totalEventsLabel.Location = new System.Drawing.Point(189, 106);
            this.totalEventsLabel.Name = "totalEventsLabel";
            this.totalEventsLabel.Size = new System.Drawing.Size(30, 33);
            this.totalEventsLabel.TabIndex = 2;
            this.totalEventsLabel.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(91, 37);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 19);
            this.label8.TabIndex = 0;
            this.label8.Text = "Total Events";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.IndianRed;
            this.panel7.Controls.Add(this.totalModulesLabel);
            this.panel7.Controls.Add(this.pictureBox6);
            this.panel7.Controls.Add(this.label10);
            this.panel7.Location = new System.Drawing.Point(21, 250);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(230, 150);
            this.panel7.TabIndex = 7;
            // 
            // totalModulesLabel
            // 
            this.totalModulesLabel.AutoSize = true;
            this.totalModulesLabel.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalModulesLabel.ForeColor = System.Drawing.Color.White;
            this.totalModulesLabel.Location = new System.Drawing.Point(189, 106);
            this.totalModulesLabel.Name = "totalModulesLabel";
            this.totalModulesLabel.Size = new System.Drawing.Size(30, 33);
            this.totalModulesLabel.TabIndex = 2;
            this.totalModulesLabel.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(91, 37);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(108, 19);
            this.label10.TabIndex = 0;
            this.label10.Text = "Total Modules";
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::TogetherCultureApp.Properties.Resources.digital__1_;
            this.pictureBox6.Location = new System.Drawing.Point(14, 37);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(71, 69);
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::TogetherCultureApp.Properties.Resources.icons8_events_64__1_;
            this.pictureBox5.Location = new System.Drawing.Point(14, 37);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(71, 69);
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::TogetherCultureApp.Properties.Resources.digital__1_;
            this.pictureBox4.Location = new System.Drawing.Point(14, 37);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 60);
            this.pictureBox4.TabIndex = 1;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::TogetherCultureApp.Properties.Resources.digital__1_;
            this.pictureBox3.Location = new System.Drawing.Point(14, 37);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(71, 69);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::TogetherCultureApp.Properties.Resources.icons8_events_64__1_;
            this.pictureBox2.Location = new System.Drawing.Point(14, 37);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(69, 69);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TogetherCultureApp.Properties.Resources.icons8_events_64__1_;
            this.pictureBox1.Location = new System.Drawing.Point(14, 37);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(71, 69);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // UserDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "UserDashboard";
            this.Size = new System.Drawing.Size(880, 565);
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label totalUnbookedEventsLabel;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label totalEventsBookedLabel;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label totalModulesUnbookedLabel;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label totalModulesBookedLabel;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label totalModulesLabel;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label totalEventsLabel;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label8;
    }
}

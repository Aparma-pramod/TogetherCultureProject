﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TogetherCultureApp
{
    public partial class LoginForm : Form
    {
        AdminHome adminHome;
        UserHome userHome;
        RegisterForm registerForm;
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public LoginForm()
        {
            InitializeComponent();
        }

        //handles the exit button click 
        private void end_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //handles the register button click 
        private void register_button_Click(object sender, EventArgs e)
        {
            RegisterForm rForm = new RegisterForm();
            rForm.Show();
            this.Hide();
        }

        //handles the password checkbox 
        private void pwd_checkBox_Changed(object sender, EventArgs e)
        {
            login_password.PasswordChar = login_show_password.Checked ? '\0' : '*';
        }
        
        //handles the login button click 
        private void loginBtn_Click(object sender, EventArgs e)
        {
            if (login_username.Text == "" || login_password.Text == "")
            {
                MessageBox.Show("Please fill all fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    try
                    {
                        connect.Open();

                        String query
                            = "SELECT * FROM Member WHERE username = @username AND password = @password";
                        using (SqlCommand cmd = new SqlCommand(query, connect))
                        {
                            cmd.Parameters.AddWithValue("@username", login_username.Text.Trim());
                            cmd.Parameters.AddWithValue("@password", login_password.Text.Trim());

                            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                            DataTable table = new DataTable();
                            adapter.Fill(table);

                            if (table.Rows.Count >= 1)
                            {

                                
                                if (login_username.Text.Trim() == "admin")
                                {
                                    adminHome = new AdminHome();
                                    adminHome.Show();
                                }
                                else
                                {
                                    SqlDataReader reader = cmd.ExecuteReader();
                                    while (reader.Read())
                                    {
                                       // Console.WriteLine("Status name: " + reader["status "].ToString());
                                        if (reader["status"].ToString().Trim().Equals("Rejected"))
                                        {
                                            MessageBox.Show("Your application is rejected!", "Information Message"
                                             , MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        }
                                        else if (reader["status"].ToString().Trim().Equals("Not approved"))
                                        {
                                            MessageBox.Show("Your application is not approved yet! Please come again and check!", "Information Message"
                                             , MessageBoxButtons.OK, MessageBoxIcon.Information);
                                        }
                                        else
                                        {
                                            UserHome.sessionMemberName = reader["username"].ToString();
                                            UserHome.sessionMemberId= (int) reader["member_id"];
                                            userHome = new UserHome();
                                            userHome.Show();
                                            MessageBox.Show("Login Successfully!", "Information Message"
                                             , MessageBoxButtons.OK, MessageBoxIcon.Information);
                                            this.Hide();
                                        }

                                        Console.WriteLine("Setting member name: " + reader["status"].ToString());
                                    }
                                    reader.Close();

                                }
                                
                            }
                            else
                            {
                                MessageBox.Show("Invalid Username/Password", "Error Message"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Error);

                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error connecting DB: " + ex, "Error Message"
                            , MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TogetherCultureApp
{
    class MessageData
    {
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public int ID { set; get; }
        public int SenderId { set; get; }
        public string SenderName { set; get; }
        public string Message { set; get; }

        public string DateTime { set; get; }


        public List<MessageData> getAllMessageData()
        {
            List<MessageData> listData = new List<MessageData>();

            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM Messages";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();


                        while (reader.Read())
                        {
                            MessageData data = new MessageData();
                            data.ID = (int)reader["msg_id"];
                            data.SenderId = (int)reader["sender_id"];
                            data.SenderName = reader["sender_name"].ToString();
                            data.Message = reader["message"].ToString();
                            data.DateTime = reader["date_time"].ToString();
                            listData.Add(data);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error connecting Database: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }
            return listData;
        }

        public string getFormattedMessage()
        {
            string result = Message.ToString().Trim() + "\t\t\t" +SenderName.ToString().Trim() + "@" + DateTime.ToString().Trim();
            return result;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TogetherCultureApp;

namespace TogetherCultureApp
{

    public partial class UserHome : Form
    {
        public static int sessionMemberId = 1;
        public static string sessionMemberName =  "user";

        public UserHome()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("Are you sure you want to logout?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (check == DialogResult.Yes)
            {
                LoginForm lForm = new LoginForm();
                lForm.Show();
                this.Hide();
            }

        }

        private void dashboard_btn_Click(object sender, EventArgs e)
        {
            dashboard.Visible = true;
            
            UserDashboard dForm = dashboard as UserDashboard;
            if (dForm != null)
            {
               // dForm.refreshData();
            }
        }

        private void events_btn_Click(object sender, EventArgs e)
        {
            dashboard.Visible = false;
            viewEvents.Visible = true;
            viewProfile.Visible = false;

            System.Console.WriteLine("VIEW EVENTS BUTTON CLICKED");
            ViewEvents dForm = viewEvents as ViewEvents;
            if (dForm != null)
            {
                viewEvents.refreshData();
            }
        }

        private void profile_btn_Click(object sender, EventArgs e)
        {
            dashboard.Visible = false;
            viewEvents.Visible = false;
            viewProfile.Visible = true;

            ViewProfile dForm = viewProfile as ViewProfile;
            if (dForm != null)
            {
                dForm.refreshData();
            }

        }

        private void chatroom_btn_Click(object sender, EventArgs e)
        {
            dashboard.Visible = false;
            viewEvents.Visible = false;
            viewProfile.Visible = false;
            viewModule.Visible = false;
            viewConnection.Visible = false;
            chatRoom.Visible = true;

            ChatRoom dForm = chatRoom as ChatRoom;
            if (dForm != null)
            {
                dForm.refreshData();
            }
        }

        private void connection_btn_Click(object sender, EventArgs e)
        {
            dashboard.Visible = false;
            viewEvents.Visible = false;
            viewProfile.Visible = false;
            viewModule.Visible = false;
            viewConnection.Visible = true;

            ViewConnections dForm = viewConnection as ViewConnections;
            if (dForm != null)
            {
                dForm.refreshData();
            }
        }

        private void modules_btn_Click(object sender, EventArgs e)
        {
            dashboard.Visible = false;
            viewEvents.Visible = false;
            viewProfile.Visible = false;
            viewModule.Visible = true;

            ViewModules  dForm = viewModule as ViewModules;
            if (dForm != null)
            {
                dForm.refreshData();
            }
        }

        private void manageUsers_btn_Click(object sender, EventArgs e)
        {

        }

        private void dashboard1_Load(object sender, EventArgs e)
        {

        }

        private void greet_label_Click(object sender, EventArgs e)
        {

        }
    }
}

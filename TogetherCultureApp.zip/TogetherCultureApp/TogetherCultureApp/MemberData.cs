﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Remoting.Contexts;
using TogetherCultureApp;

namespace TogetherCommunitySystem
{
    class MemberData
    {
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");

        public int ID { set; get; }
        public string UserName { set; get; }
        public string Password { set; get; }
        public string Email { set; get; }
        public string RegisteredDate { set; get; }
        public string Type { set; get; }
        public string Interest { set; get; }

        public string Status { set; get; }
        public List<MemberData> getMemberData()
        {
            List<MemberData> listData = new List<MemberData>();
            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT * FROM Member";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            MemberData dib = new MemberData();
                            dib.ID = (int)reader["member_id"];
                            dib.UserName = reader["username"].ToString();
                            dib.Password = reader["password"].ToString();
                            dib.Email = reader["email"].ToString();
                            dib.RegisteredDate = reader["date_register"].ToString();
                            dib.Type = reader["member_type"].ToString();
                            dib.Interest = reader["interest"].ToString();
                            dib.Status = reader["status"].ToString();
                            listData.Add(dib);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }

            return listData;
        }

        public List<MemberData> getMemberDataByType(string type)
        {
            List<MemberData> listData = new List<MemberData>();
            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();
                    string selectData = "";
                    selectData = "SELECT * FROM Member where status = @status";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@status", type);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            MemberData dib = new MemberData();
                            dib.ID = (int)reader["member_id"];
                            dib.UserName = reader["username"].ToString();
                            dib.Password = reader["password"].ToString();
                            dib.Email = reader["email"].ToString();
                            dib.RegisteredDate = reader["date_register"].ToString();
                            dib.Type = reader["member_type"].ToString();
                            dib.Interest = reader["interest"].ToString();
                            dib.Status = reader["status"].ToString();
                            listData.Add(dib);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }

            return listData;
        }


        public MemberData getCurrentMemberData()
        {
            MemberData dib = new MemberData();

            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT * FROM Member where member_id=@member_id";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);
                        SqlDataReader reader = cmd.ExecuteReader();
                        while (reader.Read())
                        {
                            dib.ID = (int)reader["member_id"];
                            dib.UserName = reader["username"].ToString();
                            dib.Password = reader["password"].ToString();
                            dib.Email = reader["email"].ToString();
                            dib.RegisteredDate = reader["date_register"].ToString();
                            dib.Type = reader["member_type"].ToString();
                            dib.Interest = reader["interest"].ToString();
                            dib.Status = reader["status"].ToString();
                            
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }
            return dib;
        }

        internal string getPassword()
        {
            return Password;
        }
    }
}

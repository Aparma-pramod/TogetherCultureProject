﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace TogetherCultureApp
{
    public partial class ViewModules : UserControl
    {
        ModuleData sampleData;
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public ViewModules()
        {
            InitializeComponent();
            displayModules();

        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            displayModules();
        }

        private String imagePath;


        public void displayModules()
        {
            ModuleData dab = new ModuleData();
            List<ModuleData> listData = dab.getAllModulesData();
            dataGridView1.DataSource = listData;
        }

        private int moduleID = -1;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                moduleID = (int)row.Cells[0].Value;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void _book_button_Click(object sender, EventArgs e)
        {
            if (
                 moduleID == -1

                )
            {
                MessageBox.Show("Please select any module", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure want to booking:"
                        + moduleID + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();
                            DateTime today = DateTime.Today;

                            string insertData = "INSERT INTO bookings " +
                            "(member_id,event_id,module_id, booking_date) " +
                            "VALUES(@member_id, @event_id, @module_id, @booking_date)";
                            using (SqlCommand cmd = new SqlCommand(insertData, connect))
                            {
                                cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);
                                cmd.Parameters.AddWithValue("@module_id", moduleID);
                                cmd.Parameters.AddWithValue("@event_id", -1);
                                cmd.Parameters.AddWithValue("@booking_date", today.ToString());
                                cmd.ExecuteNonQuery();
                                displayModules();
                                MessageBox.Show("Booked module successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using TogetherCommunitySystem;

namespace TogetherCultureApp
{
    public partial class ViewConnections : UserControl
    {
        ConnectionData sampleData;
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public ViewConnections()
        {
            InitializeComponent();

            displayConnData();

        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            displayConnData();
        }

        public void displayConnData()
        {

            ConnectionData dib = new ConnectionData();
            List<ConnectionData> listData = dib.getAllConnectionsData();
            Console.WriteLine("Display COnnection Data called.....: Total lenth: " + listData.Count);
            allConnDataGrid.DataSource = listData;
        }

        private void conn_addBtn_Click(object sender, EventArgs e)
        {
            if (queryField.Text == ""
                || typeField.Text == ""
                )
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    try
                    {
                        connect.Open();

                        string insertData = "INSERT INTO Connections " +
                                "(sender_name, sender_id, offer, need) " +
                                "VALUES(@sender_name, @sender_id, @offer, @need)";

                        using (SqlCommand cmd = new SqlCommand(insertData, connect))
                        {
                            if (typeField.Text == "offer")
                            {
                                cmd.Parameters.AddWithValue("@offer", queryField.Text);
                                cmd.Parameters.AddWithValue("@need", "");
                            }
                            else
                            {
                                cmd.Parameters.AddWithValue("@offer", "");
                                cmd.Parameters.AddWithValue("@need", queryField.Text);
                            }

                            cmd.Parameters.AddWithValue("@sender_id", UserHome.sessionMemberId);
                            cmd.Parameters.AddWithValue("@sender_name", UserHome.sessionMemberName);
                            cmd.ExecuteNonQuery();

                            displayConnData();

                            MessageBox.Show("Submitted successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            clearFields();

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
        }

        public void clearFields()
        {
            queryField.Text = "";
            typeField.Text = "";
            
        }

        


        private void connections_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }


        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}

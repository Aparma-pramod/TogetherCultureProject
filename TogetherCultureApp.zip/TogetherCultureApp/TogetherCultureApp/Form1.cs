﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TogetherCultureApp
{
    public partial class Form1 : Form
    {
        LoginForm lForm;

        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_func(object sender, EventArgs e)
        {
            panel2.Width += 10;
            if (panel2.Width >= 580)
            {
                timer1.Stop();
                lForm = new LoginForm();
                lForm.Show();
                this.Hide();

            }
        }

    }
}

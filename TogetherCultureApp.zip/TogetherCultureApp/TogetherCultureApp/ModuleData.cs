﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TogetherCultureApp
{
    class ModuleData
    {
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public int ID { set; get; }
        public string Title { set; get; }
        public string Description { set; get; }
        public float Price { set; get; }
        
        public List<ModuleData> getAllModulesData()
        {
            List<ModuleData> listData = new List<ModuleData>();

            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM modules";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();


                        while (reader.Read())
                        {
                            ModuleData dab = new ModuleData();
                            dab.ID = (int)reader["module_id"];
                            dab.Title = reader["module_name"].ToString();
                            dab.Description = reader["description"].ToString();
                            dab.Price= (float)reader["price"];
                            listData.Add(dab);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error connecting Database: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }
            return listData;
        }
    }
}

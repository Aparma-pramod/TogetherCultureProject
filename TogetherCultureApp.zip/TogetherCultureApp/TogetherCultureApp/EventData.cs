﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TogetherCultureApp
{
    class EventData
    {
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public int ID { set; get; }
        public string Title { set; get; }
        public string Description { set; get; }
        public string EventDate { set; get; }
        public int Attendance { set; get; }
        public string OrgName { set; get; }

        public List<EventData> getAllEventsData()
        {
            List<EventData> listData = new List<EventData>();

            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM events";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();


                        while (reader.Read())
                        {
                            EventData dab = new EventData();
                            dab.ID = (int)reader["event_id"];
                            dab.Title = reader["event_name"].ToString();
                            dab.Description = reader["event_description"].ToString();
                            dab.EventDate = reader["event_date"].ToString();
                            dab.Attendance = (int)reader["attendance"];
                            dab.OrgName = reader["organiser_name"].ToString();
                            listData.Add(dab);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error connecting Database: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }
            return listData;
        }


        public List<EventData> getEventsByName(string name)
        {
            List<EventData> listData = new List<EventData>();
            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM events where event_name LIKE '%"+name+"%'";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();
                        cmd.Parameters.AddWithValue("@value", name);

                        while (reader.Read())
                        {
                            EventData dab = new EventData();
                            dab.ID = (int)reader["event_id"];
                            dab.Title = reader["event_name"].ToString();
                            dab.Description = reader["event_description"].ToString();
                            dab.EventDate = reader["event_date"].ToString();
                            dab.Attendance = (int)reader["attendance"];
                            dab.OrgName = reader["organiser_name"].ToString();
                            listData.Add(dab);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error conenecting Database: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }
            return listData;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TogetherCultureApp
{
    internal class LogInSession
    {

        public int MemberID { set; get; }
        public string UserName { set; get; }
        
        public LogInSession()
        {

        }



    }
}

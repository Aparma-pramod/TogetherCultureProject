﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using TogetherCommunitySystem;
using System.IO;
using System.Reflection;
using System.Text.RegularExpressions;

namespace TogetherCultureApp
{
    public partial class ChatRoom : UserControl
    {
        FileData sfData;
        MessageData mgData;
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public ChatRoom()
        {
            InitializeComponent();

            displayChatData();

        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            displayChatData();
            displayFileData();
        }

        public void displayChatData()
        {
            chatBox.Items.Clear();
            MessageData dib = new MessageData();
            List<MessageData> listData = dib.getAllMessageData();
            Console.WriteLine("Display CHAT Data called.....: Total length: " + listData.Count);

            foreach (MessageData mdata in listData)
            {
                string res =  mdata.getFormattedMessage();
                chatBox.Items.Add(res);            
            }
            
        }

        public void displayFileData()
        {
            fileBox.Items.Clear();
            FileData dib = new FileData();
            List<FileData> listData = dib.getAllFileData();
            Console.WriteLine("Display File Data called.....: Total length: " + listData.Count);

            foreach (FileData mdata in listData)
            {
                string res = mdata.FileName;
                string mPath = mdata.FilePath;
                fileBox.Items.Add(res);
            }
        }

        private void file_box_item_clicked(object sender, EventArgs e)
        {
            string filename = fileBox.Items[fileBox.SelectedIndex].ToString();
            Console.WriteLine("Downloading file ....." + filename);

            string currentPath = System.IO.Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
            currentPath = currentPath.Replace("bin\\Debug", "");
            string finalPath = currentPath + "\\Resources\\" + filename;

            string downloadsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            

            string storedPath = downloadsPath + "\\" + filename;
            Console.WriteLine("Download Path ....." + downloadsPath);
            Console.WriteLine("Stored Path ....." + storedPath);
            System.IO.File.Copy(finalPath, storedPath, true);
            MessageBox.Show("Successfully downloaded to:" + storedPath, "Info Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void select_file_button_click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
                string selectedFilePath = "";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    
                    selectedFilePath = dialog.FileName;
                    Console.WriteLine("Selected File Path: " + selectedFilePath);
                    
                    string filename = Path.GetFileName(selectedFilePath);
                    string currentPath =     System.IO.Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);
                    currentPath = currentPath.Replace("bin\\Debug", "");
                    Console.WriteLine("current Path : " + currentPath);
                    string finalPath = currentPath +"\\Resources\\" + filename;
                    Console.WriteLine("Final copy  Path : " + finalPath);
                    System.IO.File.Copy(selectedFilePath, finalPath, true);

                    if (connect.State != ConnectionState.Open)
                    {
                        try
                        {
                            connect.Open();
                            DateTime now = DateTime.Now;

                            string insertData = "INSERT INTO Files " +
                                    "(sender_name, sender_id, file_name, file_path,date_time) " +
                                    "VALUES(@sender_name, @sender_id, @file_name,@file_path ,@date_time)";

                            using (SqlCommand cmd = new SqlCommand(insertData, connect))
                            {
                                cmd.Parameters.AddWithValue("@file_name", filename);
                                cmd.Parameters.AddWithValue("@file_path", finalPath);
                                cmd.Parameters.AddWithValue("@date_time", now.ToString());
                                cmd.Parameters.AddWithValue("@sender_id", UserHome.sessionMemberId);
                                cmd.Parameters.AddWithValue("@sender_name", UserHome.sessionMemberName);
                                cmd.ExecuteNonQuery();

                                displayChatData();
                                displayFileData();
                                queryField.Text = "";
                                MessageBox.Show("Successfully uploaded ", "Info Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                        }
                        finally
                        {
                            connect.Close();
                        }
                    }

                    
                }
                else
                {
                    Console.WriteLine("Failed to select file path....");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void message_addBtn_Click(object sender, EventArgs e)
        {
            if (queryField.Text == ""
                )
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    try
                    {
                        connect.Open();
                        DateTime now = DateTime.Now;

                        string insertData = "INSERT INTO Messages " +
                                "(sender_name, sender_id, message,date_time) " +
                                "VALUES(@sender_name, @sender_id, @message, @date_time)";

                        using (SqlCommand cmd = new SqlCommand(insertData, connect))
                        {
                            cmd.Parameters.AddWithValue("@message", queryField.Text);

                            cmd.Parameters.AddWithValue("@date_time", now.ToString());

                            cmd.Parameters.AddWithValue("@sender_id", UserHome.sessionMemberId);
                            cmd.Parameters.AddWithValue("@sender_name", UserHome.sessionMemberName);
                            cmd.ExecuteNonQuery();

                            displayChatData();
                            queryField.Text = "";
                            //MessageBox.Show("Submitted successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
        }

        public void clearFields()
        {
            queryField.Text = "";

        }


        private void connections_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }


        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void queryField_TextChanged(object sender, EventArgs e)
        {

        }

        private void selectedFilePathLabel_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TogetherCultureApp
{
    class FileData
    {
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public int ID { set; get; }
        public int SenderId { set; get; }
        public string SenderName { set; get; }
        public string FileName { set; get; }

        public string FilePath { set; get; }

        public List<FileData> getAllFileData()
        {
            List<FileData> listData = new List<FileData>();

            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM Files";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();


                        while (reader.Read())
                        {
                            FileData data = new FileData();
                            data.ID = (int)reader["msg_id"];
                            data.SenderId = (int)reader["sender_id"];
                            data.SenderName = reader["sender_name"].ToString();
                            data.FileName = reader["file_name"].ToString();
                            data.FilePath = reader["file_path"].ToString();
                            listData.Add(data);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error connecting Database: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }
            return listData;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using TogetherCommunitySystem;

namespace TogetherCultureApp
{
    public partial class ViewProfile : UserControl
    {
        MemberData memberProfile;
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public ViewProfile()
        {
            InitializeComponent();

            displayMemberData();

        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            displayMemberData();
        }

        public void displayMemberData()
        {

            MemberData dib = new MemberData();
            MemberData currentMember = dib.getCurrentMemberData();
            passwordField.Text = currentMember.Password;
            userNameField.Text = currentMember.UserName;
            memberTypeField.Text = currentMember.Type;
            interestField.Text = currentMember.Interest;
            statusField.Text = currentMember.Status;
            emailIdField.Text = currentMember.Email;

        }

        public void clearFields()
        {
            passwordField.Text = "";
            emailIdField.Text = "";
            memberTypeField.Text = "";
            interestField.Text = "";
        }

        private void member_updateBtn_Click(object sender, EventArgs e)
        {
            if ( passwordField.Text == "" ||
                emailIdField.Text == "" ||
                memberTypeField.Text == "" || 
                interestField.Text == ""
                )
            {
                MessageBox.Show("Please select any member in table", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure you want to update member:"
                        + UserHome.sessionMemberId + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();

                            string updateData = "UPDATE Member SET password = @password, email = @email" +
                                ", member_type = @member_type, interest = @interest" + " WHERE member_id = @member_id";

                            using (SqlCommand cmd = new SqlCommand(updateData, connect))
                            {
                                cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);
                                cmd.Parameters.AddWithValue("@password", passwordField.Text.Trim());
                                cmd.Parameters.AddWithValue("@email", emailIdField.Text.Trim());
                                cmd.Parameters.AddWithValue("@member_type", memberTypeField.Text.Trim());
                                cmd.Parameters.AddWithValue("@interest", interestField.Text.Trim());

                                cmd.ExecuteNonQuery();
                                displayMemberData();
                                MessageBox.Show("Updated details successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                refreshData();
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
            }
        }


        private void profile_clearBtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace TogetherCultureApp
{
    public partial class UserDashboard : UserControl
    {
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");

        public UserDashboard()
        {
            InitializeComponent();

            eventsBooked();
            unbookedEvents();
            totalEvents();

            modulesBooked();
            unbookedModules();
            totalModules();
        }

        public void refreshData()
        {

            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }

            eventsBooked();
            unbookedEvents();
            totalEvents();

            modulesBooked();
            unbookedModules();
            totalModules();
        }


        public void modulesBooked()
        {
            if (connect.State == ConnectionState.Closed)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT COUNT(module_id) FROM bookings where member_id= @member_id";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);

                        SqlDataReader reader = cmd.ExecuteReader();
                        int modsBookedCount = 0;

                        if (reader.Read())
                        {
                            modsBookedCount = Convert.ToInt32(reader[0]);

                            totalModulesBookedLabel.Text = modsBookedCount.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        public void unbookedModules()
        {
            if (connect.State == ConnectionState.Closed)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT count(module_id) FROM modules where module_id not in (select module_id from bookings where member_id = @member_id)";
                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);
                        SqlDataReader reader = cmd.ExecuteReader();
                        int unbookedCount = 0;

                        if (reader.Read())
                        {
                            unbookedCount = Convert.ToInt32(reader[0]);
                            totalModulesUnbookedLabel.Text = unbookedCount.ToString();
                        }
                    }



                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        public void totalModules()
        {
            if (connect.State == ConnectionState.Closed)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT COUNT(module_id) FROM  modules";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();
                        int modsCount = 0;

                        if (reader.Read())
                        {
                            modsCount = Convert.ToInt32(reader[0]);

                            totalModulesLabel.Text = modsCount.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }


        public void eventsBooked()
        {
            if (connect.State == ConnectionState.Closed)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT COUNT(event_id) FROM bookings where member_id= @member_id";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);

                        SqlDataReader reader = cmd.ExecuteReader();
                        int eventsBookedCount = 0;

                        if (reader.Read())
                        {
                            eventsBookedCount = Convert.ToInt32(reader[0]);

                            totalEventsBookedLabel.Text = eventsBookedCount.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        public void unbookedEvents()
        {
            if (connect.State == ConnectionState.Closed)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT count(event_id) FROM events where event_id not in (select event_id from bookings where member_id = @member_id)";
                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        cmd.Parameters.AddWithValue("@member_id", UserHome.sessionMemberId);
                        SqlDataReader reader = cmd.ExecuteReader();
                        int unbookedCount = 0;

                        if (reader.Read())
                        {
                            unbookedCount = Convert.ToInt32(reader[0]);
                            totalUnbookedEventsLabel.Text = unbookedCount.ToString();
                        }
                    }



                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        public void totalEvents()
        {
            if (connect.State == ConnectionState.Closed)
            {
                try
                {
                    connect.Open();
                    string selectData = "SELECT COUNT(event_id) FROM  events";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();
                        int eventCount = 0;

                        if (reader.Read())
                        {
                            eventCount = Convert.ToInt32(reader[0]);

                            totalEventsLabel.Text = eventCount.ToString();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connect.Close();
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TogetherCultureApp
{
    class ConnectionData
    {
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public int ID { set; get; }
        public string SenderId { set; get; }
        public string SenderName { set; get; }
        public string Offer { set; get; }

        public string Need { set; get; }

        public List<ConnectionData> getAllConnectionsData()
        {
            List<ConnectionData> listData = new List<ConnectionData>();

            if (connect.State != ConnectionState.Open)
            {
                try
                {
                    connect.Open();

                    string selectData = "SELECT * FROM Connections";

                    using (SqlCommand cmd = new SqlCommand(selectData, connect))
                    {
                        SqlDataReader reader = cmd.ExecuteReader();


                        while (reader.Read())
                        {
                            ConnectionData data = new ConnectionData();
                            data.ID = (int)reader["msg_id"];
                            data.SenderId = reader["sender_id"].ToString();
                            data.SenderName = reader["sender_name"].ToString();
                            data.Offer = reader["offer"].ToString();
                            data.Need = reader["need"].ToString();
                            listData.Add(data);
                        }

                        reader.Close();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error connecting Database: " + ex);
                }
                finally
                {
                    connect.Close();
                }
            }

            Console.WriteLine("Total length of conn list: " + listData.Count);
            return listData;
        }

    }
}

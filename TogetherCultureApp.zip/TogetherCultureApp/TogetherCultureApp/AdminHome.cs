﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TogetherCultureApp;

namespace TogetherCultureApp
{
    public partial class AdminHome : Form
    {
        public AdminHome()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logout_btn_Click(object sender, EventArgs e)
        {
            DialogResult check = MessageBox.Show("Are you sure you want to logout?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (check == DialogResult.Yes)
            {
                LoginForm lForm = new LoginForm();
                lForm.Show();
                this.Hide();
            }

        }

        private void dashboard_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = true;
            manageEvents.Visible = false;
            manageUsers.Visible = false;
            

            AdminDashboard dForm = dashboard1 as AdminDashboard;
            if (dForm != null)
            {
                dForm.refreshData();
            }
        }

        private void manage_events_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            manageEvents.Visible = true;
            manageUsers.Visible = false;
            //others.Visible = false;

            ManageEvents aForm = manageEvents as ManageEvents;
            if (aForm != null)
            {
                aForm.refreshData();
            }
        }

      
        private void manageUsers_btn_Click(object sender, EventArgs e)
        {
            dashboard1.Visible = false;
            manageEvents.Visible = false;
            manageUsers.Visible = true;
            

            ManageUsers iForm = manageUsers as ManageUsers;
            if (iForm != null)
            {
                iForm.refreshData();
            }
        }

        private void dashboard1_Load(object sender, EventArgs e)
        {

        }
    }
}


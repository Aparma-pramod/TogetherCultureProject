﻿
namespace TogetherCultureApp
{
    partial class ManageEvents
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.attendanceField = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.orgField = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.addEvent_clearBtn = new System.Windows.Forms.Button();
            this.addEvent_deleteBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.eventDateField = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.addEvent_updateBtn = new System.Windows.Forms.Button();
            this.addEvent_addbtn = new System.Windows.Forms.Button();
            this.descriptionField = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.nameField = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.show_all_button = new System.Windows.Forms.Button();
            this.filterButton = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.searchText = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.searchText);
            this.panel2.Controls.Add(this.show_all_button);
            this.panel2.Controls.Add(this.filterButton);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(313, 19);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(553, 526);
            this.panel2.TabIndex = 3;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.Location = new System.Drawing.Point(15, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Size = new System.Drawing.Size(521, 447);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "All Events";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.attendanceField);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.orgField);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.addEvent_clearBtn);
            this.panel1.Controls.Add(this.addEvent_deleteBtn);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.eventDateField);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.addEvent_updateBtn);
            this.panel1.Controls.Add(this.addEvent_addbtn);
            this.panel1.Controls.Add(this.descriptionField);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.nameField);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Location = new System.Drawing.Point(14, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(278, 526);
            this.panel1.TabIndex = 2;
            // 
            // attendanceField
            // 
            this.attendanceField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.attendanceField.Location = new System.Drawing.Point(92, 204);
            this.attendanceField.Name = "attendanceField";
            this.attendanceField.Size = new System.Drawing.Size(168, 22);
            this.attendanceField.TabIndex = 26;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(63, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 23);
            this.label5.TabIndex = 25;
            this.label5.Text = "Add New Event";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // orgField
            // 
            this.orgField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orgField.Location = new System.Drawing.Point(94, 240);
            this.orgField.Name = "orgField";
            this.orgField.Size = new System.Drawing.Size(168, 22);
            this.orgField.TabIndex = 24;
            this.orgField.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 243);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(72, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "Organiser :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // addEvent_clearBtn
            // 
            this.addEvent_clearBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.addEvent_clearBtn.FlatAppearance.BorderSize = 0;
            this.addEvent_clearBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.DarkSeaGreen;
            this.addEvent_clearBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.addEvent_clearBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addEvent_clearBtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addEvent_clearBtn.ForeColor = System.Drawing.Color.White;
            this.addEvent_clearBtn.Location = new System.Drawing.Point(143, 350);
            this.addEvent_clearBtn.Name = "addEvent_clearBtn";
            this.addEvent_clearBtn.Size = new System.Drawing.Size(99, 34);
            this.addEvent_clearBtn.TabIndex = 22;
            this.addEvent_clearBtn.Text = "CLEAR";
            this.addEvent_clearBtn.UseVisualStyleBackColor = false;
            this.addEvent_clearBtn.Click += new System.EventHandler(this.addBooks_clearBtn_Click);
            // 
            // addEvent_deleteBtn
            // 
            this.addEvent_deleteBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.addEvent_deleteBtn.FlatAppearance.BorderSize = 0;
            this.addEvent_deleteBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.DarkSeaGreen;
            this.addEvent_deleteBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.addEvent_deleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addEvent_deleteBtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addEvent_deleteBtn.ForeColor = System.Drawing.Color.White;
            this.addEvent_deleteBtn.Location = new System.Drawing.Point(24, 350);
            this.addEvent_deleteBtn.Name = "addEvent_deleteBtn";
            this.addEvent_deleteBtn.Size = new System.Drawing.Size(99, 34);
            this.addEvent_deleteBtn.TabIndex = 21;
            this.addEvent_deleteBtn.Text = "DELETE";
            this.addEvent_deleteBtn.UseVisualStyleBackColor = false;
            this.addEvent_deleteBtn.Click += new System.EventHandler(this.addEvents_deleteBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 204);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 16);
            this.label3.TabIndex = 19;
            this.label3.Text = "Attendance:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // eventDateField
            // 
            this.eventDateField.Location = new System.Drawing.Point(93, 168);
            this.eventDateField.Name = "eventDateField";
            this.eventDateField.Size = new System.Drawing.Size(167, 20);
            this.eventDateField.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(21, 169);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 16);
            this.label2.TabIndex = 17;
            this.label2.Text = "Date:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addEvent_updateBtn
            // 
            this.addEvent_updateBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.addEvent_updateBtn.FlatAppearance.BorderSize = 0;
            this.addEvent_updateBtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.DarkSeaGreen;
            this.addEvent_updateBtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.addEvent_updateBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addEvent_updateBtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addEvent_updateBtn.ForeColor = System.Drawing.Color.White;
            this.addEvent_updateBtn.Location = new System.Drawing.Point(143, 298);
            this.addEvent_updateBtn.Name = "addEvent_updateBtn";
            this.addEvent_updateBtn.Size = new System.Drawing.Size(99, 34);
            this.addEvent_updateBtn.TabIndex = 16;
            this.addEvent_updateBtn.Text = "UPDATE";
            this.addEvent_updateBtn.UseVisualStyleBackColor = false;
            this.addEvent_updateBtn.Click += new System.EventHandler(this.addEvents_updateBtn_Click);
            // 
            // addEvent_addbtn
            // 
            this.addEvent_addbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.addEvent_addbtn.FlatAppearance.BorderSize = 0;
            this.addEvent_addbtn.FlatAppearance.CheckedBackColor = System.Drawing.Color.DarkSeaGreen;
            this.addEvent_addbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.addEvent_addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addEvent_addbtn.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addEvent_addbtn.ForeColor = System.Drawing.Color.White;
            this.addEvent_addbtn.Location = new System.Drawing.Point(24, 298);
            this.addEvent_addbtn.Name = "addEvent_addbtn";
            this.addEvent_addbtn.Size = new System.Drawing.Size(99, 34);
            this.addEvent_addbtn.TabIndex = 15;
            this.addEvent_addbtn.Text = "ADD";
            this.addEvent_addbtn.UseVisualStyleBackColor = false;
            this.addEvent_addbtn.Click += new System.EventHandler(this.addEvents_addBtn_Click);
            // 
            // descriptionField
            // 
            this.descriptionField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.descriptionField.Location = new System.Drawing.Point(94, 127);
            this.descriptionField.Name = "descriptionField";
            this.descriptionField.Size = new System.Drawing.Size(168, 22);
            this.descriptionField.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(12, 127);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(75, 16);
            this.label7.TabIndex = 11;
            this.label7.Text = "Description:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nameField
            // 
            this.nameField.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameField.Location = new System.Drawing.Point(94, 89);
            this.nameField.Name = "nameField";
            this.nameField.Size = new System.Drawing.Size(168, 22);
            this.nameField.TabIndex = 10;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 16);
            this.label6.TabIndex = 9;
            this.label6.Text = "Event Name:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // show_all_button
            // 
            this.show_all_button.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.show_all_button.FlatAppearance.BorderSize = 0;
            this.show_all_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.show_all_button.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.show_all_button.ForeColor = System.Drawing.Color.White;
            this.show_all_button.Location = new System.Drawing.Point(451, 16);
            this.show_all_button.Name = "show_all_button";
            this.show_all_button.Size = new System.Drawing.Size(74, 26);
            this.show_all_button.TabIndex = 28;
            this.show_all_button.Text = "SHOW ALL";
            this.show_all_button.UseVisualStyleBackColor = false;
            this.show_all_button.Click += new System.EventHandler(this.event_show_all_button_click);
            // 
            // filterButton
            // 
            this.filterButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.filterButton.FlatAppearance.BorderSize = 0;
            this.filterButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.filterButton.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.filterButton.ForeColor = System.Drawing.Color.White;
            this.filterButton.Location = new System.Drawing.Point(380, 15);
            this.filterButton.Name = "filterButton";
            this.filterButton.Size = new System.Drawing.Size(65, 26);
            this.filterButton.TabIndex = 25;
            this.filterButton.Text = "FILTER";
            this.filterButton.UseVisualStyleBackColor = false;
            this.filterButton.Click += new System.EventHandler(this.event_filter_button_click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(148, 22);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 14);
            this.label8.TabIndex = 27;
            this.label8.Text = "Search By:";
            // 
            // searchText
            // 
            this.searchText.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchText.Location = new System.Drawing.Point(225, 16);
            this.searchText.Name = "searchText";
            this.searchText.Size = new System.Drawing.Size(149, 22);
            this.searchText.TabIndex = 27;
            // 
            // ManageEvents
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "ManageEvents";
            this.Size = new System.Drawing.Size(880, 565);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button addEvent_updateBtn;
        private System.Windows.Forms.Button addEvent_addbtn;
        private System.Windows.Forms.TextBox descriptionField;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox nameField;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker eventDateField;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button addEvent_clearBtn;
        private System.Windows.Forms.Button addEvent_deleteBtn;
        private System.Windows.Forms.TextBox orgField;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox attendanceField;
        private System.Windows.Forms.TextBox searchText;
        private System.Windows.Forms.Button show_all_button;
        private System.Windows.Forms.Button filterButton;
        private System.Windows.Forms.Label label8;
    }
}

﻿
namespace TogetherCultureApp
{
    partial class ViewProfile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.ClearMemberButton = new System.Windows.Forms.Button();
            this.UpdateMemberButton = new System.Windows.Forms.Button();
            this.interestField = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.memberTypeField = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.emailIdField = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.passwordField = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.userNameField = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.statusField = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.statusField);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.ClearMemberButton);
            this.panel1.Controls.Add(this.UpdateMemberButton);
            this.panel1.Controls.Add(this.interestField);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.memberTypeField);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.emailIdField);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.passwordField);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.userNameField);
            this.panel1.Controls.Add(this.label2);
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel1.Location = new System.Drawing.Point(18, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(845, 523);
            this.panel1.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(371, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 19);
            this.label5.TabIndex = 23;
            this.label5.Text = "My Profile";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(250, 338);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 16);
            this.label8.TabIndex = 21;
            this.label8.Text = "Membership Status:";
            // 
            // ClearMemberButton
            // 
            this.ClearMemberButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.ClearMemberButton.FlatAppearance.BorderSize = 0;
            this.ClearMemberButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClearMemberButton.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearMemberButton.ForeColor = System.Drawing.Color.White;
            this.ClearMemberButton.Location = new System.Drawing.Point(420, 397);
            this.ClearMemberButton.Name = "ClearMemberButton";
            this.ClearMemberButton.Size = new System.Drawing.Size(100, 33);
            this.ClearMemberButton.TabIndex = 20;
            this.ClearMemberButton.Text = "CLEAR";
            this.ClearMemberButton.UseVisualStyleBackColor = false;
            this.ClearMemberButton.Click += new System.EventHandler(this.profile_clearBtn_Click);
            // 
            // UpdateMemberButton
            // 
            this.UpdateMemberButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.UpdateMemberButton.FlatAppearance.BorderSize = 0;
            this.UpdateMemberButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UpdateMemberButton.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateMemberButton.ForeColor = System.Drawing.Color.White;
            this.UpdateMemberButton.Location = new System.Drawing.Point(292, 397);
            this.UpdateMemberButton.Name = "UpdateMemberButton";
            this.UpdateMemberButton.Size = new System.Drawing.Size(100, 33);
            this.UpdateMemberButton.TabIndex = 18;
            this.UpdateMemberButton.Text = "UPDATE";
            this.UpdateMemberButton.UseVisualStyleBackColor = false;
            this.UpdateMemberButton.Click += new System.EventHandler(this.member_updateBtn_Click);
            // 
            // interestField
            // 
            this.interestField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.interestField.FormattingEnabled = true;
            this.interestField.Items.AddRange(new object[] {
            "caring",
            "sharing",
            "creating",
            "experiencing",
            "working"});
            this.interestField.Location = new System.Drawing.Point(375, 284);
            this.interestField.Name = "interestField";
            this.interestField.Size = new System.Drawing.Size(144, 24);
            this.interestField.TabIndex = 11;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(313, 287);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "Interest:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // memberTypeField
            // 
            this.memberTypeField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.memberTypeField.FormattingEnabled = true;
            this.memberTypeField.Items.AddRange(new object[] {
            "Community Member",
            "Key Access Member",
            "Creative Workspace Member"});
            this.memberTypeField.Location = new System.Drawing.Point(375, 234);
            this.memberTypeField.Name = "memberTypeField";
            this.memberTypeField.Size = new System.Drawing.Size(144, 24);
            this.memberTypeField.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(277, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 16);
            this.label6.TabIndex = 8;
            this.label6.Text = "Member Type:";
            // 
            // emailIdField
            // 
            this.emailIdField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailIdField.Location = new System.Drawing.Point(375, 188);
            this.emailIdField.Name = "emailIdField";
            this.emailIdField.Size = new System.Drawing.Size(145, 23);
            this.emailIdField.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(326, 191);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(43, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Email:";
            // 
            // passwordField
            // 
            this.passwordField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordField.Location = new System.Drawing.Point(375, 147);
            this.passwordField.Name = "passwordField";
            this.passwordField.Size = new System.Drawing.Size(145, 23);
            this.passwordField.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(303, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password :";
            // 
            // userNameField
            // 
            this.userNameField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userNameField.Location = new System.Drawing.Point(375, 92);
            this.userNameField.Name = "userNameField";
            this.userNameField.ReadOnly = true;
            this.userNameField.Size = new System.Drawing.Size(145, 23);
            this.userNameField.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(301, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "User Name:";
            // 
            // statusField
            // 
            this.statusField.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statusField.Location = new System.Drawing.Point(375, 335);
            this.statusField.Name = "statusField";
            this.statusField.ReadOnly = true;
            this.statusField.Size = new System.Drawing.Size(145, 23);
            this.statusField.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(131, 476);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(600, 19);
            this.label1.TabIndex = 25;
            this.label1.Text = "(Note: Please check your membership status , in case not approved, contact admin)" +
    "";
            // 
            // ViewProfile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "ViewProfile";
            this.Size = new System.Drawing.Size(880, 565);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox passwordField;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox userNameField;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox emailIdField;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox interestField;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox memberTypeField;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button ClearMemberButton;
        private System.Windows.Forms.Button UpdateMemberButton;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox statusField;
        private System.Windows.Forms.Label label1;
    }
}

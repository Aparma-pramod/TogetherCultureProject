﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.SqlClient;
using TogetherCommunitySystem;

namespace TogetherCultureApp
{
    public partial class ManageUsers : UserControl
    {
        MemberData memberList;
        SqlConnection connect = new SqlConnection(@"data source=DESKTOP-C8P35CJ; database=culturedb; integrated security=SSPI;TrustServerCertificate=True;");
        public ManageUsers()
        {
            InitializeComponent();

            displayMemberData();

        }

        public void refreshData()
        {
            if (InvokeRequired)
            {
                Invoke((MethodInvoker)refreshData);
                return;
            }
            displayMemberData();
        }

        public void displayMemberData()
        {
            MemberData dib = new MemberData();
            List<MemberData> listData = dib.getMemberData();
            allMemberDataGrid.DataSource = listData;
        }

        private void view_member_addBtn_Click(object sender, EventArgs e)
        {
            if (userNameField.Text == ""
                || passwordField.Text == ""
                || emailIdField.Text == ""
                || memberTypeField.Text == ""
                || interestField.Text == ""
                || registeredDateField.Value == null
                || statusField.Text == ""
                )
            {
                MessageBox.Show("Please fill all blank fields", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    try
                    {
                        connect.Open();

                        String checkUsername = "SELECT COUNT(*) FROM Member WHERE username = @username";

                        using (SqlCommand checkCMD = new SqlCommand(checkUsername, connect))
                        {
                            checkCMD.Parameters.AddWithValue("@username", userNameField.Text.Trim());
                            int count = (int)checkCMD.ExecuteScalar();

                            if (count >= 1)
                            {
                                MessageBox.Show(userNameField.Text.Trim()
                                    + " is already taken", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            else
                            {
                                string insertData = "INSERT INTO Member " +
                                "(username, password, email, date_register, member_type,interest, status) " +
                                "VALUES(@username, @password, @email, @date_register, @member_type, @interest, @status)";

                                using (SqlCommand cmd = new SqlCommand(insertData, connect))
                                {
                                    cmd.Parameters.AddWithValue("@username", userNameField.Text.Trim());
                                    cmd.Parameters.AddWithValue("@password", passwordField.Text.Trim());
                                    cmd.Parameters.AddWithValue("@email", emailIdField.Text.Trim());
                                    cmd.Parameters.AddWithValue("@date_register", registeredDateField.Value);
                                    cmd.Parameters.AddWithValue("@member_type", memberTypeField.Text.Trim());
                                    cmd.Parameters.AddWithValue("@status", statusField.Text.Trim());
                                    cmd.Parameters.AddWithValue("@interest", interestField.Text.Trim());


                                    cmd.ExecuteNonQuery();

                                    displayMemberData();

                                    MessageBox.Show("Added member successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    clearFields();

                                }
                            }

                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    }
                    finally
                    {
                        connect.Close();
                    }
                }
            }
        }

        public void clearFields()
        {
            registeredDateField.Text = "";
            userNameField.Text = "";
            passwordField.Text = "";
            emailIdField.Text = "";
            memberTypeField.Text = "";
            interestField.Text = "";
            statusField.Text = "";
        }

        int memberId = 0;
        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = allMemberDataGrid.Rows[e.RowIndex];
                memberId = (int)row.Cells[0].Value;
                userNameField.Text = row.Cells[1].Value.ToString();
                passwordField.Text = row.Cells[2].Value.ToString();
                emailIdField.Text = row.Cells[3].Value.ToString();
                registeredDateField.Text = row.Cells[4].Value.ToString();
                memberTypeField.Text = row.Cells[5].Value.ToString();
                interestField.Text = row.Cells[6].Value.ToString();
                statusField.Text = row.Cells[7].Value.ToString();
            }
        }

        private void show_all_button_click(object sender, EventArgs e)
        {
            displayMemberData();
        }

        private void user_filter_button_click(object sender, EventArgs e)
        {
            if (searchType.Text == "")
            {
                MessageBox.Show("Please select search type", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                MemberData dib = new MemberData();
                string type = searchType.Text;
                if ( type == "Individual Members")
                {
                    type = "Approved";
                }
                else
                {
                    type = "Not approved";
                }
                List<MemberData> listData = dib.getMemberDataByType(type);
                allMemberDataGrid.DataSource = listData;
            }
        }

        private void view_events_button_click(object sender, EventArgs e)
        {
            if (memberId <=0 )
            {
                MessageBox.Show("Please select any member", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string query = "SELECT event_name,event_date from events, bookings where events.event_id = bookings.event_id and bookings.member_id = @member_id";

                if (connect.State != ConnectionState.Open)
                {
                        try
                        {
                            connect.Open();
                            using (SqlCommand cmd = new SqlCommand(query, connect))
                            {
                                cmd.Parameters.AddWithValue("@member_id", memberId);
                                SqlDataReader reader = cmd.ExecuteReader();
                                string displayText = "";
                                while (reader.Read())
                                {
                                    displayText += reader["event_name"].ToString().Trim() + " on " + reader["event_date"].ToString().Trim() + "\n";
                                }
                                reader.Close();

                                if (displayText == "")
                                {
                                    MessageBox.Show("No events Booked", "Information Message"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                else
                                {
                                    MessageBox.Show("Events Booked:\n" + displayText, "Information Message"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                
            }
        }

        private void member_updateBtn_Click(object sender, EventArgs e)
        {
            if (
                 userNameField.Text == ""
                || passwordField.Text == ""
                || emailIdField.Text == ""
                )
            {
                MessageBox.Show("Please select any member in table", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure you want to update member:"
                        + memberId + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();

                            string updateData = "UPDATE Member SET username = @username, password = @password, email = @email" +
                                ", date_register = @date_register, member_type = @member_type, interest = @interest, status = @status" + " WHERE member_id = @member_id";

                            using (SqlCommand cmd = new SqlCommand(updateData, connect))
                            {
                                cmd.Parameters.AddWithValue("@member_id", memberId);
                                cmd.Parameters.AddWithValue("@username", userNameField.Text.Trim());
                                cmd.Parameters.AddWithValue("@password", passwordField.Text.Trim());
                                cmd.Parameters.AddWithValue("@email", emailIdField.Text.Trim());
                                cmd.Parameters.AddWithValue("@member_type", memberTypeField.Text.Trim());
                                cmd.Parameters.AddWithValue("@interest", interestField.Text.Trim());
                                cmd.Parameters.AddWithValue("@status", statusField.Text.Trim());
                                cmd.Parameters.AddWithValue("@date_register", registeredDateField.Value);
                                cmd.ExecuteNonQuery();
                                displayMemberData();
                                MessageBox.Show("Updated member successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                clearFields();
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }

                }
            }
        }

        private void member_deleteBtn_Click(object sender, EventArgs e)
        {
            if (
               userNameField.Text == ""
              || passwordField.Text == ""
              || emailIdField.Text == ""
              )
            {
                MessageBox.Show("Please select any member in table", "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (connect.State != ConnectionState.Open)
                {
                    DialogResult check = MessageBox.Show("Are you sure you want to DELETE Issue ID:"
                        + memberId + "?", "Confirmation Message", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                    if (check == DialogResult.Yes)
                    {
                        try
                        {
                            connect.Open();
                            string updateData = "DELETE FROM Member WHERE member_id = @member_id";
                            using (SqlCommand cmd = new SqlCommand(updateData, connect))
                            {
                                cmd.Parameters.AddWithValue("@member_id", memberId);
                                cmd.ExecuteNonQuery();
                                displayMemberData();
                                MessageBox.Show("Deleted member successfully!", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                clearFields();
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex, "Error Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        finally
                        {
                            connect.Close();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Cancelled.", "Information Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }

        private void user_clearBbtn_Click(object sender, EventArgs e)
        {
            clearFields();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}

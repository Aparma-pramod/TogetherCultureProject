﻿
using System;

namespace TogetherCultureApp
{
    partial class UserHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.greet_label = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dashboard = new TogetherCultureApp.UserDashboard();
            this.viewEvents = new TogetherCultureApp.ViewEvents();
            this.viewProfile = new TogetherCultureApp.ViewProfile();
            this.viewModule = new TogetherCultureApp.ViewModules();
            this.viewConnection = new TogetherCultureApp.ViewConnections();
            this.chatRoom = new TogetherCultureApp.ChatRoom();
            this.user_chatroom_button = new System.Windows.Forms.Button();
            this.user_connection_button = new System.Windows.Forms.Button();
            this.user_modules_button = new System.Windows.Forms.Button();
            this.logout_btn = new System.Windows.Forms.Button();
            this.user_profile_button = new System.Windows.Forms.Button();
            this.user_events_button = new System.Windows.Forms.Button();
            this.user_dashboard_button = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1100, 35);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(13, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(215, 18);
            this.label2.TabIndex = 1;
            this.label2.Text = "Together Culture | User Section";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1082, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(14)))), ((int)(((byte)(128)))), ((int)(((byte)(87)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.user_chatroom_button);
            this.panel2.Controls.Add(this.user_connection_button);
            this.panel2.Controls.Add(this.user_modules_button);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.logout_btn);
            this.panel2.Controls.Add(this.user_profile_button);
            this.panel2.Controls.Add(this.user_events_button);
            this.panel2.Controls.Add(this.user_dashboard_button);
            this.panel2.Controls.Add(this.greet_label);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(220, 576);
            this.panel2.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(49, 531);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Log out";
            // 
            // greet_label
            // 
            this.greet_label.AutoSize = true;
            this.greet_label.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.greet_label.ForeColor = System.Drawing.Color.White;
            this.greet_label.Location = new System.Drawing.Point(41, 131);
            this.greet_label.Name = "greet_label";
            this.greet_label.Size = new System.Drawing.Size(115, 19);
            this.greet_label.TabIndex = 1;
            this.greet_label.Text = "Welcome, " + sessionMemberName;
            this.greet_label.Click += new System.EventHandler(this.greet_label_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dashboard);
            this.panel3.Controls.Add(this.viewEvents);
            this.panel3.Controls.Add(this.viewProfile);
            this.panel3.Controls.Add(this.viewModule);
            this.panel3.Controls.Add(this.viewConnection);
            this.panel3.Controls.Add(this.chatRoom);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(220, 35);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(880, 576);
            this.panel3.TabIndex = 2;
            // 
            // dashboard
            // 
            this.dashboard.Location = new System.Drawing.Point(0, 0);
            this.dashboard.Name = "dashboard";
            this.dashboard.Size = new System.Drawing.Size(880, 565);
            this.dashboard.TabIndex = 3;
            this.dashboard.Load += new System.EventHandler(this.dashboard1_Load);
            // 
            // viewEvents
            // 
            this.viewEvents.Location = new System.Drawing.Point(0, 0);
            this.viewEvents.Name = "viewEvents";
            this.viewEvents.Size = new System.Drawing.Size(880, 565);
            this.viewEvents.TabIndex = 2;
            // 
            // viewProfile
            // 
            this.viewProfile.Location = new System.Drawing.Point(0, 0);
            this.viewProfile.Name = "viewProfile";
            this.viewProfile.Size = new System.Drawing.Size(880, 565);
            this.viewProfile.TabIndex = 4;
            // 
            // viewModule
            // 
            this.viewModule.Location = new System.Drawing.Point(0, 0);
            this.viewModule.Name = "viewModule";
            this.viewModule.Size = new System.Drawing.Size(880, 565);
            this.viewModule.TabIndex = 5;
            // 
            // viewConnection
            // 
            this.viewConnection.Location = new System.Drawing.Point(0, 0);
            this.viewConnection.Name = "viewConnection";
            this.viewConnection.Size = new System.Drawing.Size(880, 565);
            this.viewConnection.TabIndex = 6;
            // 
            // chatRoom
            // 
            this.chatRoom.Location = new System.Drawing.Point(0, 0);
            this.chatRoom.Name = "chatRoom";
            this.chatRoom.Size = new System.Drawing.Size(880, 565);
            this.chatRoom.TabIndex = 7;
            // 
            // user_chatroom_button
            // 
            this.user_chatroom_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.user_chatroom_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_chatroom_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_chatroom_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_chatroom_button.ForeColor = System.Drawing.Color.White;
            this.user_chatroom_button.Image = global::TogetherCultureApp.Properties.Resources.chatroom;
            this.user_chatroom_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user_chatroom_button.Location = new System.Drawing.Point(8, 389);
            this.user_chatroom_button.Name = "user_chatroom_button";
            this.user_chatroom_button.Size = new System.Drawing.Size(200, 45);
            this.user_chatroom_button.TabIndex = 10;
            this.user_chatroom_button.Text = "CHAT ROOM";
            this.user_chatroom_button.UseVisualStyleBackColor = true;
            this.user_chatroom_button.Click += new System.EventHandler(this.chatroom_btn_Click);
            // 
            // user_connection_button
            // 
            this.user_connection_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.user_connection_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_connection_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_connection_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_connection_button.ForeColor = System.Drawing.Color.White;
            this.user_connection_button.Image = global::TogetherCultureApp.Properties.Resources.download__1_;
            this.user_connection_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user_connection_button.Location = new System.Drawing.Point(8, 338);
            this.user_connection_button.Name = "user_connection_button";
            this.user_connection_button.Size = new System.Drawing.Size(200, 45);
            this.user_connection_button.TabIndex = 9;
            this.user_connection_button.Text = "CONNECTION BOARD";
            this.user_connection_button.UseVisualStyleBackColor = true;
            this.user_connection_button.Click += new System.EventHandler(this.connection_btn_Click);
            // 
            // user_modules_button
            // 
            this.user_modules_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.user_modules_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_modules_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_modules_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_modules_button.ForeColor = System.Drawing.Color.White;
            this.user_modules_button.Image = global::TogetherCultureApp.Properties.Resources.digital__1_;
            this.user_modules_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user_modules_button.Location = new System.Drawing.Point(8, 287);
            this.user_modules_button.Name = "user_modules_button";
            this.user_modules_button.Size = new System.Drawing.Size(200, 45);
            this.user_modules_button.TabIndex = 8;
            this.user_modules_button.Text = "VIEW MODULES";
            this.user_modules_button.UseVisualStyleBackColor = true;
            this.user_modules_button.Click += new System.EventHandler(this.modules_btn_Click);
            // 
            // logout_btn
            // 
            this.logout_btn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.logout_btn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.logout_btn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.logout_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logout_btn.ForeColor = System.Drawing.Color.White;
            this.logout_btn.Image = global::TogetherCultureApp.Properties.Resources.icons8_logout_rounded_up_filled_32px;
            this.logout_btn.Location = new System.Drawing.Point(8, 522);
            this.logout_btn.Name = "logout_btn";
            this.logout_btn.Size = new System.Drawing.Size(35, 35);
            this.logout_btn.TabIndex = 6;
            this.logout_btn.UseVisualStyleBackColor = true;
            this.logout_btn.Click += new System.EventHandler(this.logout_btn_Click);
            // 
            // user_profile_button
            // 
            this.user_profile_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.user_profile_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_profile_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_profile_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_profile_button.ForeColor = System.Drawing.Color.White;
            this.user_profile_button.Image = global::TogetherCultureApp.Properties.Resources.icons8_user_50;
            this.user_profile_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user_profile_button.Location = new System.Drawing.Point(8, 444);
            this.user_profile_button.Name = "user_profile_button";
            this.user_profile_button.Size = new System.Drawing.Size(200, 45);
            this.user_profile_button.TabIndex = 4;
            this.user_profile_button.Text = "PROFILE";
            this.user_profile_button.UseVisualStyleBackColor = true;
            this.user_profile_button.Click += new System.EventHandler(this.profile_btn_Click);
            // 
            // user_events_button
            // 
            this.user_events_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.user_events_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_events_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_events_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_events_button.ForeColor = System.Drawing.Color.White;
            this.user_events_button.Image = global::TogetherCultureApp.Properties.Resources.icons8_events_64__3_;
            this.user_events_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user_events_button.Location = new System.Drawing.Point(8, 236);
            this.user_events_button.Name = "user_events_button";
            this.user_events_button.Size = new System.Drawing.Size(200, 45);
            this.user_events_button.TabIndex = 3;
            this.user_events_button.Text = "VIEW EVENTS";
            this.user_events_button.UseVisualStyleBackColor = true;
            this.user_events_button.Click += new System.EventHandler(this.events_btn_Click);
            // 
            // user_dashboard_button
            // 
            this.user_dashboard_button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.user_dashboard_button.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_dashboard_button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkSeaGreen;
            this.user_dashboard_button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.user_dashboard_button.ForeColor = System.Drawing.Color.White;
            this.user_dashboard_button.Image = global::TogetherCultureApp.Properties.Resources.icons8_dashboard_32px;
            this.user_dashboard_button.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.user_dashboard_button.Location = new System.Drawing.Point(8, 185);
            this.user_dashboard_button.Name = "user_dashboard_button";
            this.user_dashboard_button.Size = new System.Drawing.Size(200, 45);
            this.user_dashboard_button.TabIndex = 2;
            this.user_dashboard_button.Text = "DASHBOARD";
            this.user_dashboard_button.UseVisualStyleBackColor = true;
            this.user_dashboard_button.Click += new System.EventHandler(this.dashboard_btn_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TogetherCultureApp.Properties.Resources.logo__1_;
            this.pictureBox1.Location = new System.Drawing.Point(58, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // UserHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 611);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UserHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }


        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button user_events_button;
        private System.Windows.Forms.Button user_dashboard_button;
        private System.Windows.Forms.Label greet_label;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button user_profile_button;
        private System.Windows.Forms.Button logout_btn;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel3;
        private UserDashboard dashboard;
        private ViewEvents viewEvents;
        private ViewProfile viewProfile;
        private ViewModules viewModule;

        private ViewConnections viewConnection;
        private ChatRoom chatRoom;


        private System.Windows.Forms.Button user_modules_button;
        private System.Windows.Forms.Button user_chatroom_button;
        private System.Windows.Forms.Button user_connection_button;
    }
}